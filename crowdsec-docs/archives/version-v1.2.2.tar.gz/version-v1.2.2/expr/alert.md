---
id: alert
title: Alert
sidebar_position: 3
---

An `Alert` is the runtime representation of a bucket overflow.

The representation of the object can be found here : 

[Alert object documentation](https://pkg.go.dev/github.com/crowdsecurity/crowdsec/pkg/types#RuntimeAlert)

