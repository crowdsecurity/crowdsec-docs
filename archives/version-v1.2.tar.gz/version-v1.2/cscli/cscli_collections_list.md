---
id: cscli_collections_list
title: cscli collections list
---
## cscli collections list

List all collections or given one

### Synopsis

List all collections or given one

```
cscli collections list collection [-a] [flags]
```

### Examples

```
cscli collections list
```

### Options

```
  -a, --all    List as well disabled items
  -h, --help   help for list
```

### Options inherited from parent commands

```
  -c, --config string   path to crowdsec config file (default "/etc/crowdsec/config.yaml")
      --debug           Set logging to debug.
      --error           Set logging to error.
      --info            Set logging to info.
  -o, --output string   Output format : human, json, raw.
      --trace           Set logging to trace.
      --warning         Set logging to warning.
```

### SEE ALSO

* [cscli collections](/cscli/cscli_collections.md)	 - Manage collections from hub

