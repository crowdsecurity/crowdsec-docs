---
id: intro
title: Introduction
sidebar_position: 1
---

Collections are bundle of parsers, scenarios, postoverflows that form a coherent package.


