---
id: contributing_code
title: CrowdSec
sidebar_position: 1
---

# Contribute to CrowdSec

 - If you want to report a bug, you can use [the GitHub bugtracker](https://github.com/crowdsecurity/crowdsec/issues)
 - If you want to suggest an improvement, you can either use [the GitHub bugtracker](https://github.com/crowdsecurity/crowdsec/issues) or drop by our [Discourse](http://discourse.crowdsec.net) to chat with the team 

