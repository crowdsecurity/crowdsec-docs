---
title: v0.X not supported
id: intro
---

:::warning

This version is not supported anymore. Migrate to v1.2.X or later.

:::