---
title: FAQ
id: faq
---

# FREQUENTLY ASKED QUESTIONS

## What is CrowdSec ?

CrowdSec is a security open-source software. See the [overview](/docs/intro).

## CrowdSec v0.X is not supported anymore

:::warning

This version is not supported anymore. Migrate to v1.2.X or later.

:::