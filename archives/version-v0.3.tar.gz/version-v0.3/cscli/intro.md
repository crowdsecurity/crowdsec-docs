---
title: v0.X not supported
id: cscli
---

:::warning

This version is not supported anymore. Migrate to v1.2.X or later.

:::