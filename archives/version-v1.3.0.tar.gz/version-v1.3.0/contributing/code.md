---
id: contributing_code
title: CrowdSec
sidebar_position: 1
---

# Contribute to CrowdSec

 - If you want to report a bug, you can use [the github bugtracker](https://github.com/crowdsecurity/crowdsec/issues)
 - If you want to suggest an improvement you can use either [the github bugtracker](https://github.com/crowdsecurity/crowdsec/issues) or the [CrowdSecurity discourse](http://discourse.crowdsec.net) if you want to discuss 

